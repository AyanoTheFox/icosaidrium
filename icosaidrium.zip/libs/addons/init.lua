atlasparser = require((...) .. "/atlasparser")
require((...) .. "/gradient")